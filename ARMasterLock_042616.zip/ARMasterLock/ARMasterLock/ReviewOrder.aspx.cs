﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ARMasterLock
{
    public partial class ReviewOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Order myOrder = (Order)Session["Order"];

            GridView1.DataSource = myOrder.OrderLines;
            GridView1.DataBind();

            
        }
    }
}