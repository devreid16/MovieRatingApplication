﻿using System.Web.UI;

namespace ARMasterLock.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}