﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ARMasterLock
{
    public class Order
    {
        public IList<OrderLine> OrderLines { get; set; }

        public string orderId { get; set; }
        public string orderStatus { get; set; }
        public DateTime orderDate { get; set; }
        public string customerId { get; set; }
        public string orderQty { get; set; }
        public decimal orderTax { get; set; }
        public decimal orderTotal { get; set; }

    }
}