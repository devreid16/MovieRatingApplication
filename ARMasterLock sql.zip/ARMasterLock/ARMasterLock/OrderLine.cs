﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ARMasterLock
{
    public class OrderLine
    {
        public int orderId { get; set; }
        public int orderItemId { get; set; }
        public int orderNumber { get; set; }
        public string productQty { get; set; }
        public string productPrice { get; set; }
        public string ProductName { get; set; }
        public string ProductType { get; set; }
        public string ProductMdlNum { get; set; }
        public string ProductDetail { get; set; }
    }
}
