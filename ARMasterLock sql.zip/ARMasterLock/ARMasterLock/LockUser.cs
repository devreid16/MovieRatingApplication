﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.Entity.Core.Metadata.Edm;
using System.Linq;
using System.Web;

namespace ARMasterLock
{
    public class LockUser
    {        
        public string FirstName { get; set; }
        public string LastName  { get; set; }
        public string Street    { get; set; }
        public string Address   { get; set; }
        public string City      { get; set; }
        public string State     { get; set; }
        public string ZipCode   { get; set; }
        public string Phone     { get; set; }
        public string Email     { get; set; }
        public string UserName { get; set; }
        public string Password  { get; set; }        

        public LockUser()
        {

        }
        /// <summary>
        ///  creates user account and generate message
        /// </summary>
        /// <returns>message to user</returns>


        public string CreateAccount()
        {
            DataAccess da = new DataAccess();

            ArrayList parms = new ArrayList();

            SqlParameter fNameParameter = new SqlParameter();
            fNameParameter.Value = FirstName;
            fNameParameter.ParameterName = "FirstName";
            parms.Add(fNameParameter);

            SqlParameter lNameParameter = new SqlParameter();
            lNameParameter.Value = LastName;
            lNameParameter.ParameterName = "LastName";
            parms.Add(lNameParameter);           

            SqlParameter addressParameter = new SqlParameter();
            addressParameter.Value = Address;
            addressParameter.ParameterName = "Address";
            parms.Add(addressParameter);

            SqlParameter cityParameter = new SqlParameter();
            cityParameter.Value = City;
            cityParameter.ParameterName = "City";
            parms.Add(cityParameter);

            SqlParameter ddlStateListParameter = new SqlParameter("@State", State);
            ddlStateListParameter.Value = State;
            ddlStateListParameter.ParameterName = "State";
            parms.Add(ddlStateListParameter);
                                  
            SqlParameter zipCodeParameter = new SqlParameter();
            zipCodeParameter.Value = ZipCode;
            zipCodeParameter.ParameterName = "ZipCode";
            parms.Add(zipCodeParameter);

            SqlParameter phoneParameter = new SqlParameter();
            phoneParameter.Value = Phone;
            phoneParameter.ParameterName = "Phone";
            parms.Add(phoneParameter);

            SqlParameter emailParameter = new SqlParameter();
            emailParameter.Value = Email;
            emailParameter.ParameterName = "Email";
            parms.Add(emailParameter);

            SqlParameter userNameParameter = new SqlParameter();
            userNameParameter.Value = UserName;
            userNameParameter.ParameterName = "UserName";
            parms.Add(userNameParameter);

            SqlParameter passwordParameter = new SqlParameter();
            passwordParameter.Value = Password;
            passwordParameter.ParameterName = "Password";
            parms.Add(passwordParameter);

            da.InsertUpdateData("InsertNewUser", parms);

            //congratulations... set variables before you call 
            string message = "Congratuations " + FirstName + " " + LastName +
                    " you created your Username: " + UserName;

            return message;
        }

        public override string ToString()
        {
            //   return base.ToString();
            //congratulations... set variables before you call 
            string message = "Congratuations " + FirstName + " " + LastName +
                    " you created your Username: " + UserName;

            return message;


        }
    }
}