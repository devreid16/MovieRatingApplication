﻿using System.Web.UI;

namespace MasterSample.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}