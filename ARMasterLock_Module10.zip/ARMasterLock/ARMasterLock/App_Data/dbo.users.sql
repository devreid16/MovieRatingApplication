﻿CREATE TABLE [dbo].[Table]
(
	[customerId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [userName] VARCHAR(50) NOT NULL, 
    [fName] VARCHAR(50) NOT NULL, 
    [lName] VARCHAR(50) NOT NULL
)
