﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ARMasterLock
{
    public partial class ReviewOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Order myOrder = (Order)Session["Order"];

            LockOrder OLocks = new LockOrder();
            OrderLine orderLine = new OrderLine();
           // OLocks.productMdlNum = lkType.DataTextField;
           // OLocks.productQty = qtyItem.Text;

            //add item to collection
            SqlDataReader da;

            da = OLocks.OrderLocks();

            GridOdrs.DataSource = da;
            GridOdrs.DataBind();

            OLocks.OrderLines = new List<OrderLine>();
            OLocks.OrderLines.Add(orderLine);



            GridOdrs.DataSource = myOrder.OrderLines;
            GridOdrs.DataBind();

            lblOutput.Text = myOrder.ToString();


        }

        protected void BtnDone_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}