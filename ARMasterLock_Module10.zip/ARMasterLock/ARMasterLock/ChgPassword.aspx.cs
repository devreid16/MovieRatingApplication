﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ARMasterLock
{
    public partial class ChgPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, LoginCancelEventArgs e)
        {

        }      
        
        protected void OnChangingPassword(object sender, EventArgs e)
        {

            string password = ChangePassword1.CurrentPassword;

            if (!ChangePassword1.CurrentPassword.Equals(ChangePassword1.NewPassword, 
                StringComparison.CurrentCultureIgnoreCase))            
                
            {
                int rowsAffected = 0;

                string query = "UPDATE [users] SET [password] = @NewPassword WHERE [userName] = @userName AND [password] = @CurrentPassword";

                string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;

                using (SqlConnection con = new SqlConnection(constr))

                {

                    using (SqlCommand cmd = new SqlCommand(query))

                    {

                        using (SqlDataAdapter sda = new SqlDataAdapter())

                        {

                            cmd.Parameters.AddWithValue("@userName", this.Page.User.Identity.Name);

                            cmd.Parameters.AddWithValue("@CurrentPassword", ChangePassword1.CurrentPassword);

                            cmd.Parameters.AddWithValue("@NewPassword", ChangePassword1.NewPassword);

                            cmd.Connection = con;

                            con.Open();

                            rowsAffected = cmd.ExecuteNonQuery();

                            con.Close();

                        }

                    }

                    if (rowsAffected > 0)

                    {

                        lblMessage.ForeColor = Color.Green;

                        lblMessage.Text = "Password has been changed successfully.";

                    }

                    else

                    {

                        lblMessage.ForeColor = Color.Red;

                        lblMessage.Text = "Password does not match with our database records.";

                    }

                }

            }

            else

            {

                lblMessage.ForeColor = Color.Red;

                lblMessage.Text = "Old Password and New Password must not be equal.";                

            }

                //e.Cancel = true;

        }
    
    }
}