﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ARMasterLock
{
    public partial class reviewOrder : System.Web.UI.Page
    {
        Order myOrder = new Order();
        protected void Page_Load(object sender, EventArgs e)
        {
            //page load 

            //orderID
            myOrder.orderId = "@orderId";
        }
        protected void submit_Click1(object sender, EventArgs e)
        {
            //create item from user selection
            OrderLine orderLine = new OrderLine();
            orderLine.ProductName = "@productName";
            orderLine.ProductDetail = "@productDetail";
            orderLine.productPrice = "@productPrice";
            orderLine.productQty = "@productQty";

            //add item to collection
            myOrder.OrderLines = new List<OrderLine>();
            myOrder.OrderLines.Add(orderLine);

            //now we need to persist order object

            Session["Order"] = myOrder;

            //Response.Redirect("ReviewOrder.aspx");
        }

        protected void submit_Click2(object sender, EventArgs e)
        {
            myOrder = (Order)Session["Order"];

            //create item
            OrderLine orderLine = new OrderLine();
            orderLine.ProductName = "@productName";
            orderLine.ProductDetail = "@productDetail";
            orderLine.productPrice = "@productPrice";
            orderLine.productQty = "@productQty";

            //add item to collection

            myOrder.OrderLines.Add(orderLine);


            //now we need to persist order object

            Session["Order"] = myOrder;
            Response.Redirect("ReviewOrder.aspx");
        }
    }
}