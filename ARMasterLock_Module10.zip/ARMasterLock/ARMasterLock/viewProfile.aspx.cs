﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ARMasterLock
{
    public partial class viewProfile : System.Web.UI.Page

    {
        
        public string userName;

        protected void Page_Load(object sender, EventArgs e)
        {
            viewProfile1();
            
        }

        public SqlDataReader viewProfile1()
        {
            DataAccess da = new DataAccess();

            ArrayList parms = new ArrayList();
            Session["userName"] = userName;
            

            SqlParameter userNameParameter = new SqlParameter("@userName", userName);
            userNameParameter.Value = userName;
            userNameParameter.ParameterName = "userName";
            parms.Add(userNameParameter);

            SqlDataReader gv;

            gv = da.GetDataReader("getProfile", parms);

            ///returns Gridview with selected products

            return gv;
        }
    }
}